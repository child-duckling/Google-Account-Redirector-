# Google-Account-Redirector-
Redirects google page from one account to a specified account
